const express = require('express');
const { exec } = require('child_process');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3001;

// Use CORS to allow all origins
app.use(cors());

// Middleware to parse JSON requests
app.use(bodyParser.json());

// POST endpoint to execute batch commands (for reference)
app.post('/execute', (req, res) => {
    const { command } = req.body;

    if (!command) {
        return res.status(400).json({ error: 'No command provided' });
    }

    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing command: ${error.message}`);
            return res.status(500).json({ error: error.message });
        }

        if (stderr) {
            console.error(`Command stderr: ${stderr}`);
            return res.status(500).json({ stderr: stderr });
        }

        console.log(`Command stdout: ${stdout}`);
        return res.status(200).json({ stdout: stdout });
    });
});

// POST endpoint to move the mouse
app.post('/moveMouse', (req, res) => {
    const { x, y } = req.body;

    if (typeof x !== 'number' || typeof y !== 'number') {
        return res.status(400).json({ error: 'Invalid coordinates provided' });
    }

    const psCommand = `Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point(${x}, ${y})`;

    exec(`powershell -Command "${psCommand}"`, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error moving mouse: ${error.message}`);
            return res.status(500).json({ error: error.message });
        }

        if (stderr) {
            console.error(`Mouse move stderr: ${stderr}`);
            return res.status(500).json({ stderr: stderr });
        }

        console.log(`Mouse moved to (${x}, ${y})`);
        return res.status(200).json({ message: `Mouse moved to (${x}, ${y})` });
    });
});

// POST endpoint to click the mouse
app.post('/clickMouse', (req, res) => {
    const { button } = req.body; // button can be 'left' or 'right'

    if (!button || (button !== 'left' && button !== 'right')) {
        return res.status(400).json({ error: 'Invalid button type. Use "left" or "right".' });
    }

    const buttonCode = button === 'left' ? 0 : 1; // 0 for left, 1 for right
    const psCommand = `Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Cursor]::Position = [System.Windows.Forms.Cursor]::Position; [System.Windows.Forms.SendKeys]::SendWait("{${button === 'left' ? 'L' : 'R'}}")`;

    exec(`powershell -Command "${psCommand}"`, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error clicking mouse: ${error.message}`);
            return res.status(500).json({ error: error.message });
        }

        if (stderr) {
            console.error(`Mouse click stderr: ${stderr}`);
            return res.status(500).json({ stderr: stderr });
        }

        console.log(`Mouse clicked ${button} button.`);
        return res.status(200).json({ message: `Mouse clicked ${button} button.` });
    });
});

// POST endpoint to send keyboard input
app.post('/type', (req, res) => {
    const { text } = req.body;

    if (!text) {
        return res.status(400).json({ error: 'No text provided to type.' });
    }

    const psCommand = `Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait("${text}")`;

    exec(`powershell -Command "${psCommand}"`, (error, stdout, stderr) => {
        if (error) {
            console.error(`Error typing text: ${error.message}`);
            return res.status(500).json({ error: error.message });
        }

        if (stderr) {
            console.error(`Typing stderr: ${stderr}`);
            return res.status(500).json({ stderr: stderr });
        }

        console.log(`Typed text: ${text}`);
        return res.status(200).json({ message: `Typed text: ${text}` });
    });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
